import{W as a}from"./chunk-MVKIOC5N.js";import"./chunk-LYBDN2BO.js";export{a as HomeComponent};
