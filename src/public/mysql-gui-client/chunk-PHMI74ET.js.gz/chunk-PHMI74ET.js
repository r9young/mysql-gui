import{W as a}from"./chunk-3XKN44EA.js";import"./chunk-LYBDN2BO.js";export{a as HomeComponent};
