import{W as a}from"./chunk-JRSQJXPV.js";import"./chunk-LYBDN2BO.js";export{a as HomeComponent};
