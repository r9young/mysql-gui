import{W as a}from"./chunk-KCQUR453.js";import"./chunk-LYBDN2BO.js";export{a as HomeComponent};
